AI NOBORu — https://www.aiofonesown.com/

# Checking the determinant constructions: code and saved results

English reader’s guide · 16 September 2026
Translated from the original Japanese README dated 15 September 2026.

This package examines the terms, signs, and completeness of determinant constructions. For the definitions, general proofs, and relationship to earlier scholarship, see the website’s research record. The code does not establish what a historical author intended or who first discovered a result.

## Where to start

- `seki_dihedral.py` defines and tests Construction A, based on cyclic permutation and reversal.
- `verify_even_and_kokyu.py` tests Construction B, based on even permutations and swapping the final two entries, together with the one-direction construction described as *kōkyū*-type and its canceling pairs.
- `resultant_bridge.py` computes resultants of polynomials of degrees 5, 6, and 7 and compares different methods.
- `results/` contains saved outputs and CSV files of representative arrangements for sizes 5, 6, and 7.

The original code, tests, saved outputs, Japanese README, and attribution files are unchanged. Adding this guide does not mean those historical research runs were repeated on the date above. Consult the individual files for their environments, inputs, and results. Original comments or output labels may be in Japanese.

## Reproduce the calculations

Use Python 3. The following two scripts require only the standard library:

```sh
python seki_dihedral.py --output dihedral-results.json
python verify_even_and_kokyu.py --output even-kokyu-results.json
```

The checks enumerate all terms for Constructions A and B at sizes 3–9 and for the *kōkyū*-type construction at sizes 2–9. Canceling pairs are enumerated at sizes 3–6. Enumeration takes factorial time; these scripts are intended for investigating small sizes.

The resultant calculations and unit tests use SymPy. The saved results record version 1.14.0:

```sh
python -m pip install sympy==1.14.0
python resultant_bridge.py --output-dir .
python -m unittest test_seki_dihedral test_resultant_bridge -v
```

Existing files are overwritten when an output path has the same name. Work in a separate folder to preserve the supplied results.

## What the checks establish—and what they do not

The checks examine the terms and signs of the defined constructions and compare their numerical determinants and resultants. Verification over a finite range is different from a proof for every size. These scripts do not check every historical numbering, omission, or arrangement in Ishiguro’s sources, or establish agreement with every manuscript. Images of the original historical sources are not redistributed here.

This package does not include the website’s power-sum or convergence calculations. It is a research-code archive, not the source of all 70 website calculators.

Keep the original attribution and third-party notices when redistributing the material.
