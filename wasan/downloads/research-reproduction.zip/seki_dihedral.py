# AI NOBORu — https://www.aiofonesown.com/
#!/usr/bin/env python3
"""Exact reconstruction of corrected koshiki/shajo, not a new fast determinant.

Historical motivation: O. Takenouchi, RIMS Kokyuroku 1677 (2010), 20-26.
The code is a modern construction. It does not reconstruct all surviving Seki
manuscripts, establish historical priority, or solve quintic equations in radicals.
The main enumeration retains n! terms and is intended for small-n research.
No network, service, Git, or host-configuration operations are performed.
"""
from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction
from itertools import permutations
import json
from math import factorial, prod
from pathlib import Path
import platform
import random
import sys
import time
from typing import Iterator, Sequence

Permutation = tuple[int, ...]
Exact = int | Fraction


def parity(exponent: int) -> int:
    return -1 if exponent & 1 else 1


def _check_order(n: int, k: int = 0) -> None:
    if not isinstance(n, int) or n < 1 or not isinstance(k, int):
        raise ValueError('n must be a positive integer and k an integer')


def left_sign(n: int, k: int = 0) -> int:
    _check_order(n,k)
    return parity(k*(n-1))


def right_sign(n: int, k: int = 0) -> int:
    _check_order(n,k)
    return parity(n*(n-1)//2 + k*(n-1))


def legacy_right_sign(n: int, k: int = 0) -> int:
    """The legacy parity rule as formalized in the user's message.

    For even n the first sign is taken to be +, as in the supplied table.
    This function alone is NOT a reconstruction of Seki's whole algorithm.
    """
    _check_order(n,k)
    return (-1 if n % 2 else 1) * left_sign(n,k)


def rotate(p: Permutation, k: int) -> Permutation:
    k %= len(p)
    return p[k:]+p[:k]


def sign_by_inversions(p: Sequence[int]) -> int:
    return parity(sum(p[i] > p[j] for i in range(len(p)) for j in range(i+1,len(p))))


def sign_by_cycles(p: Sequence[int]) -> int:
    """Independent reference using number of disjoint cycles."""
    seen = [False]*len(p)
    cycles = 0
    for i in range(len(p)):
        if not seen[i]:
            cycles += 1
            j = i
            while not seen[j]:
                seen[j] = True
                j = p[j]
    return parity(len(p)-cycles)


def representatives(n: int) -> Iterator[tuple[Permutation, int]]:
    """One representative of each dihedral orbit, with its permutation sign.

    Start with the unique unoriented 3-cycle. Relabel an (n-1)-cycle by +1;
    inserting the new 0 at its n-1 edges gives all n-cycles up to rotation and
    reversal, once each. Tail rotations change sign by (-1)**(k*(n-2)).
    """
    if not isinstance(n,int) or n < 3:
        raise ValueError('dihedral representatives require n >= 3')
    if n == 3:
        yield (0,1,2), 1
        return
    for p, weight in representatives(n-1):
        tail = tuple(x+1 for x in p)
        for k in range(n-1):
            yield (0,) + rotate(tail,k), weight * parity(k*(n-2))


def expanded_terms(n: int, mode: str = 'corrected') -> Iterator[tuple[Permutation,int]]:
    """Yield monomial index and integer coefficient; never evaluates a CAS det."""
    modes = {'corrected','legacy_right','no_block_sign','diagonal_only'}
    if mode not in modes:
        raise ValueError(f'mode must be one of {sorted(modes)}')
    if n < 3:
        raise ValueError('expanded_terms requires n >= 3')
    reps = [(tuple(range(n)),1)] if mode=='diagonal_only' else representatives(n)
    for p, weight in reps:
        if mode == 'no_block_sign':
            weight = 1
        rev = p[::-1]
        for k in range(n):
            yield rotate(p,k), weight * left_sign(n,k)
            rs = legacy_right_sign(n,k) if mode=='legacy_right' else right_sign(n,k)
            yield rotate(rev,k), weight * rs


def _matrix(a: Sequence[Sequence[Exact]]) -> list[list[Exact]]:
    b = [list(row) for row in a]
    n = len(b)
    if any(len(row)!=n for row in b):
        raise ValueError('matrix must be square')
    if any(not isinstance(x,(int,Fraction)) for row in b for x in row):
        raise TypeError('use int or Fraction entries; floating point is not accepted')
    return b


def determinant(a: Sequence[Sequence[Exact]], mode: str = 'corrected') -> Exact:
    """Evaluate the reconstructed expansion; factorial, not a fast general solver."""
    if mode not in {'corrected','legacy_right','no_block_sign','diagonal_only'}:
        raise ValueError('unknown reconstruction mode')
    b = _matrix(a)
    n = len(b)
    if n==0:
        return 1
    if n==1:
        return b[0][0]
    if n==2:
        return b[0][0]*b[1][1]-b[0][1]*b[1][0]
    total: Exact = 0
    for p, coefficient in expanded_terms(n,mode):
        term: Exact = coefficient
        for i,j in enumerate(p):
            term *= b[i][j]
            if not term:
                break
        total += term
    return total


def reference_determinant(a: Sequence[Sequence[Exact]]) -> Fraction:
    """Independent exact Gaussian elimination, not the diagonal construction."""
    b = [[Fraction(x) for x in row] for row in _matrix(a)]
    n = len(b)
    result = Fraction(1)
    for k in range(n):
        pivot = next((i for i in range(k,n) if b[i][k]), None)
        if pivot is None:
            return Fraction(0)
        if pivot != k:
            b[k],b[pivot] = b[pivot],b[k]
            result = -result
        value = b[k][k]
        result *= value
        for i in range(k+1,n):
            factor = b[i][k]/value
            for j in range(k+1,n):
                b[i][j] -= factor*b[k][j]
            b[i][k] = Fraction(0)
    return result


def permutation_matrix(p: Sequence[int]) -> list[list[int]]:
    if sorted(p)!=list(range(len(p))):
        raise ValueError('p is not a permutation of 0,...,n-1')
    return [[int(j==p[i]) for j in range(len(p))] for i in range(len(p))]


def run_verification(max_n: int = 9) -> dict:
    if not 3 <= max_n <= 10:
        raise ValueError('verification max_n must be between 3 and 10')
    start = time.perf_counter()
    output = {'scope':'Modern reconstruction; finite verification plus separately written proof',
              'environment':{'python':sys.version,'platform':platform.platform()},
              'sign_checks':{},'coverage':[], 'numerical':[], 'counterexamples':[],
              'historical_priority':'NOT_CLAIMED; see Takenouchi 2010 p26, citing Kanno 1798'}
    count=0
    for n in range(3,257):
        p=tuple(range(n))
        for k in range(n):
            assert left_sign(n,k)==sign_by_cycles(rotate(p,k))
            assert right_sign(n,k)==sign_by_cycles(rotate(p[::-1],k))
            count+=2
    output['sign_checks']={'orders':[3,256], 'individual_terms':count,'pass':True,
        'matching_legacy_orders_3_to_24':[n for n in range(3,25) if right_sign(n)==legacy_right_sign(n)]}
    for n in range(3,max_n+1):
        seen=set()
        incorrect_signs=0
        reps=list(representatives(n))
        assert len(reps)==factorial(n-1)//2
        assert all(w==sign_by_inversions(p) for p,w in reps)
        for p,w in expanded_terms(n):
            assert p not in seen, (n,p,'duplicate')
            seen.add(p)
            incorrect_signs += (w != sign_by_inversions(p))
        assert len(seen)==factorial(n) and incorrect_signs==0
        # A tuple produced by the algorithm is always a permutation. Cardinality n!
        # and uniqueness prove coverage for this fixed n without a numerical matrix.
        output['coverage'].append({'n':n,'representatives':len(reps),'terms':len(seen),
            'positive_representatives':sum(w==1 for _,w in reps),
            'negative_representatives':sum(w==-1 for _,w in reps),
            'duplicates':0,'missing':0,'wrong_coefficients':incorrect_signs,'pass':True})
    rng=random.Random(20260913)
    for n in range(3,max_n+1):
        random_count=12 if n<=8 else 3
        matrices=[[[rng.randrange(-4,5) for _ in range(n)] for _ in range(n)] for __ in range(random_count)]
        eye=permutation_matrix(tuple(range(n)))
        reversal=permutation_matrix(tuple(range(n-1,-1,-1)))
        p=list(range(n));p[0],p[1]=p[1],p[0]
        transposition=permutation_matrix(p)
        repeated=[row[:] for row in matrices[0]];repeated[1]=repeated[0][:]
        matrices.extend([eye,reversal,transposition,[[0]*n for _ in range(n)],repeated])
        for a in matrices:
            assert determinant(a)==reference_determinant(a)
        output['numerical'].append({'n':n,'matrices':len(matrices),'pass':True})
    for n in (5,6,7):
        a=permutation_matrix(tuple(range(n-1,-1,-1)))
        output['counterexamples'].append({'label':f'reversal_{n}', 'matrix':a,
            'reference':str(reference_determinant(a)),
            'legacy_right_with_correct_representatives':str(determinant(a,'legacy_right')),
            'corrected':str(determinant(a))})
    a=permutation_matrix((1,0,2,3,4))
    output['counterexamples'].append({'label':'transposition_5','matrix':a,
        'reference':str(reference_determinant(a)), 'corrected_diagonal_only':str(determinant(a,'diagonal_only')),
        'missing_block_sign':str(determinant(a,'no_block_sign')),'corrected':str(determinant(a))})
    output['counterexamples'].append({'label':'all_ones_5','reference':'0',
        'corrected_diagonal_only':str(determinant([[1]*5 for _ in range(5)],'diagonal_only')),
        'corrected':str(determinant([[1]*5 for _ in range(5)]))})
    output['total_covered_monomials']=sum(x['terms'] for x in output['coverage'])
    output['total_numerical_matrices']=sum(x['matrices'] for x in output['numerical'])
    output['elapsed_seconds']=round(time.perf_counter()-start,3)
    output['result']='PASS'
    return output


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--max-n',type=int,default=9)
    args=parser.parse_args()
    result=run_verification(args.max_n)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('result','total_covered_monomials','total_numerical_matrices','elapsed_seconds')},ensure_ascii=False))

if __name__=='__main__':
    main()
