# AI NOBORu — https://www.aiofonesown.com/
"""Modern exact constructions, not attribution of intent to a historical author.
Run: python verify_even_and_kokyu.py --output even-kokyu-results.json
Python standard library only. Full enumeration has factorial cost.
"""
from itertools import permutations
from collections import Counter
from math import factorial
from pathlib import Path
import argparse,json
def sign(p):
    return (-1)**sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))
def verify():
    coverage=[]; kokyu=[]
    for n in range(2,10):
        terms={}; one_direction={}
        for tail in permutations(range(1,n)):
            p=(0,)+tail
            for k in range(n):
                base=p[::-1]; q=base[k:]+base[:k]
                w=sign(p)*(-1)**(n*(n-1)//2+k*(n-1))
                assert q not in one_direction and w==sign(q)
                one_direction[q]=w
            if n<3 or sign(p)!=1:continue
            right=p[:-2]+(p[-1],p[-2])
            for k in range(n):
                for base,w in [(p,(-1)**(k*(n-1))),(right,-(-1)**(k*(n-1)))]:
                    q=base[k:]+base[:k]
                    assert q not in terms and w==sign(q)
                    terms[q]=w
        assert len(one_direction)==factorial(n)
        kokyu.append(dict(n=n,terms=len(one_direction),duplicates=0,wrong_signs=0))
        if n>=3:
            assert len(terms)==factorial(n)
            coverage.append(dict(n=n,representatives=factorial(n-1)//2,terms=len(terms),duplicates=0,wrong_signs=0))
    cancellation=[]
    for n in range(3,7):
        counts=Counter(); signs=Counter()
        for j in range(1,n):
            for p in permutations(range(n)):
                monomial=tuple(sorted((r,j if c==0 else c) for r,c in enumerate(p)))
                key=(j,monomial)
                counts[key]+=1; signs[key]+=sign(p)
        assert set(counts.values())=={2} and set(signs.values())=={0}
        assert len(counts)==(n-1)*factorial(n)//2
        cancellation.append(dict(n=n,pairs=len(counts)))
    return dict(result='PASS',even_reconstruction=coverage,kokyu_modern=kokyu,cancellation=cancellation,
                historical_intent='NOT_PROVEN',historical_number_matching='NOT_COMPLETED')
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();result=verify()
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(result=result['result'],even_terms=sum(x['terms'] for x in result['even_reconstruction']),kokyu_terms=sum(x['terms'] for x in result['kokyu_modern']))))
