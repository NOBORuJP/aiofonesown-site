# AI NOBORu — https://www.aiofonesown.com/
#!/usr/bin/env python3
"""Connect the reconstructed determinant to equal-degree polynomial elimination.

The Bézoutian is built from (f(x)g(y)-f(y)g(x))/(x-y). Only the independent
reference evaluation calls SymPy.resultant. No solution of general quintic
polynomials by radicals, or new resultant theory, is claimed.
"""
from __future__ import annotations
import argparse
import csv
from fractions import Fraction
import json
from pathlib import Path
import platform
import sys
import sympy as sp
from seki_dihedral import determinant, reference_determinant, representatives


def bezout_matrix(f, g, x):
    """Return the ascending-power Bézout matrix for equal positive degrees."""
    fp=sp.Poly(f,x,domain=sp.QQ); gp=sp.Poly(g,x,domain=sp.QQ)
    n=fp.degree()
    if n < 1 or n != gp.degree():
        raise ValueError('equal positive degrees are required')
    y=sp.Dummy('y')
    numerator=sp.expand(fp.as_expr()*gp.as_expr().subs(x,y)-fp.as_expr().subs(x,y)*gp.as_expr())
    quotient,remainder=sp.div(numerator,x-y,x)
    if sp.expand(remainder)!=0:
        raise ArithmeticError('Bézout numerator did not divide exactly')
    q=sp.Poly(sp.expand(quotient),x,y)
    return sp.Matrix(n,n,lambda i,j:q.coeff_monomial(x**i*y**j))


def exact_matrix(b):
    return [[Fraction(int(b[i,j].p),int(b[i,j].q)) for j in range(b.cols)] for i in range(b.rows)]


def run(output_dir: Path):
    x=sp.Symbol('x')
    results=[]
    for n in (5,6,7):
        pairs=[('generic',x**n+x+1,x**n-2*x+3),
               ('shared_root',(x-2)*(x**(n-1)+x+1),(x-2)*(2*x**(n-1)-3*x+2)),
               ('difference_one',x**n+x+1,x**n+x+2)]
        for label,f,g in pairs:
            f=sp.expand(f);g=sp.expand(g)
            b=bezout_matrix(f,g,x); a=exact_matrix(b)
            got=determinant(a);gaussian=reference_determinant(a)
            resultant=sp.resultant(f,g,x)
            expected=Fraction(int(resultant.p),int(resultant.q))*(-1)**(n*(n-1)//2)
            if got!=expected or gaussian!=expected:
                raise AssertionError((n,label,got,gaussian,expected))
            results.append({'n':n,'case':label,'f':str(f),'g':str(g),
                            'matrix':[[str(v) for v in row] for row in a],
                            'resultant':str(resultant),'corrected_determinant':str(got),
                            'reference_determinant':str(gaussian),'pass':True})
        with (output_dir/f'representatives_n{n}.csv').open('w',encoding='utf-8',newline='') as out:
            writer=csv.writer(out);writer.writerow(['index','sign','permutation_one_based'])
            for index,(p,w) in enumerate(representatives(n),1):
                writer.writerow([index,w,' '.join(str(i+1) for i in p)])
    result={'scope':'Modern equal-degree Bézoutian check, not a historical transcript',
            'environment':{'python':sys.version,'sympy':sp.__version__,'platform':platform.platform()},
            'identity':'det(B) = (-1)^(n(n-1)/2) Res(f,g); equal positive degrees',
            'cases':results,'case_count':len(results),'result':'PASS'}
    (output_dir/'resultant_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'result':'PASS','case_count':len(results),
        'generic_resultants':[c['resultant'] for c in results if c['case']=='generic']},ensure_ascii=False))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path,default=Path('.'))
    args=parser.parse_args()
    if not args.output_dir.is_dir():
        parser.error('--output-dir must already exist')
    run(args.output_dir)
