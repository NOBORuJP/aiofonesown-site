# AI NOBORu — https://www.aiofonesown.com/
import unittest
import sympy as sp
from resultant_bridge import bezout_matrix
from seki_dihedral import determinant, reference_determinant

class BezoutBridgeTests(unittest.TestCase):
    def test_quadratic_entries(self):
        x = sp.Symbol('x')
        b = bezout_matrix(x*x+x+1, x*x-2*x+3, x)
        self.assertEqual(b, sp.Matrix([[5,2],[2,-3]]))

    def test_all_three_equal_degree_orders(self):
        x = sp.Symbol('x')
        for n in (5,6,7):
            f=x**n+x+1; g=x**n-2*x+3
            b=bezout_matrix(f,g,x)
            a=[[int(b[i,j]) for j in range(n)] for i in range(n)]
            expected=(-1)**(n*(n-1)//2)*int(sp.resultant(f,g,x))
            self.assertEqual(determinant(a), expected)
            self.assertEqual(reference_determinant(a), expected)

    def test_shared_root(self):
        x=sp.Symbol('x')
        n=5
        f=(x-2)*(x**(n-1)+x+1)
        g=(x-2)*(2*x**(n-1)-3*x+2)
        b=bezout_matrix(f,g,x)
        a=[[int(b[i,j]) for j in range(n)] for i in range(n)]
        self.assertEqual(determinant(a), 0)

if __name__=='__main__':
    unittest.main(verbosity=2)
