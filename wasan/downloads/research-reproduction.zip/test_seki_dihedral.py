# AI NOBORu — https://www.aiofonesown.com/
"""Exact, independently checkable tests for the modern reconstruction."""
from collections import Counter
from fractions import Fraction
from itertools import permutations
from math import factorial
import unittest

import seki_dihedral as sd

class ReconstructionTests(unittest.TestCase):
    def test_right_sign_regressions(self):
        self.assertEqual(sd.right_sign(5, 0), 1)
        self.assertEqual(sd.right_sign(6, 0), -1)

    def test_period_four(self):
        matches = [n for n in range(3, 25)
                   if all(sd.right_sign(n,k) == sd.legacy_right_sign(n,k) for k in range(n))]
        self.assertEqual(matches, [3,4,7,8,11,12,15,16,19,20,23,24])

    def test_actual_permutation_signs(self):
        for n in range(3, 40):
            base = tuple(range(n))
            for k in range(n):
                self.assertEqual(sd.left_sign(n,k), sd.sign_by_inversions(sd.rotate(base,k)))
                self.assertEqual(sd.right_sign(n,k), sd.sign_by_inversions(sd.rotate(base[::-1],k)))

    def test_representative_weights(self):
        for n in range(3,8):
            reps = list(sd.representatives(n))
            self.assertEqual(len(reps), factorial(n-1)//2)
            for p, weight in reps:
                self.assertEqual(weight, sd.sign_by_inversions(p))

    def test_symbolic_coefficients_not_only_numerical_values(self):
        for n in range(3,8):
            seen = Counter()
            for p, coefficient in sd.expanded_terms(n):
                seen[p] += 1
                self.assertEqual(coefficient, sd.sign_by_inversions(p))
            self.assertEqual(set(seen), set(permutations(range(n))))
            self.assertEqual(set(seen.values()), {1})

    def test_single_block_does_not_compute_a_general_determinant(self):
        p = (1,0,2,3,4)
        a = sd.permutation_matrix(p)
        self.assertEqual(sd.determinant(a, mode='diagonal_only'), 0)
        self.assertEqual(sd.determinant(a), -1)

    def test_block_sign_cannot_be_dropped(self):
        a = sd.permutation_matrix((1,0,2,3,4))
        self.assertEqual(sd.determinant(a, mode='no_block_sign'), 1)
        self.assertEqual(sd.determinant(a), -1)

    def test_all_ones_counterexample(self):
        a = [[1]*5 for _ in range(5)]
        self.assertEqual(sd.determinant(a, mode='diagonal_only'), 10)
        self.assertEqual(sd.determinant(a), 0)

    def test_edge_dimensions(self):
        self.assertEqual(sd.determinant([]), 1)
        self.assertEqual(sd.determinant([[7]]), 7)
        self.assertEqual(sd.determinant([[1,2],[3,4]]), -2)

    def test_rational_input(self):
        a = [[Fraction(i+1,j+2) + (1 if i==j else 0) for j in range(5)] for i in range(5)]
        self.assertEqual(sd.determinant(a), sd.reference_determinant(a))

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError):
            sd.determinant([[1,2]])
        with self.assertRaises(TypeError):
            sd.determinant([[1.0]])
        with self.assertRaises(ValueError):
            list(sd.representatives(2))
        with self.assertRaises(ValueError):
            sd.determinant([[1]], mode='unknown')

    def test_dense_and_singular(self):
        for n in (5,6,7):
            a = [[((i+1)**2 + (j+2)**3 + 3*i*j) % 13 - 6 for j in range(n)] for i in range(n)]
            self.assertEqual(sd.determinant(a), sd.reference_determinant(a))
            a[1] = a[0][:]
            self.assertEqual(sd.determinant(a), 0)

if __name__ == '__main__':
    unittest.main(verbosity=2)
