AI NOBORU — 和算計算室 Web設置キット
https://www.aiofonesown.com/

このキットの wasan/ フォルダを、既存Webサイトの公開ルート直下へ配置してください。既存のトップページを置き換える必要はありません。

設置後の主な入口
- 日本語: /wasan/
- 英語: /wasan/en/
- JavaScript不要の英語83術一覧: /wasan/en/calculators.html
- ダウンロード: /wasan/downloads.html / /wasan/en/downloads.html

配信時の確認
1. .mjs が JavaScript のMIME typeで配信されること
2. /wasan/ と /wasan/en/ の計算室が読み込めること
3. 日本語・英語の相互リンクが動くこと
4. downloads/ のZIPが取得できること
5. 既存サイトのCSPを使う場合、ES modules と同梱スクリプトを許可すること

埋め込み例は embed-snippet.html / embed-snippet-en.html、iframe例は iframe-snippet.html / iframe-snippet-en.html を参照してください。
