AI NOBORU — WASAN Mathematics Laboratory website kit
https://www.aiofonesown.com/

Place the wasan/ folder under the public root of an existing website. You do not need to replace the site's existing home page.

Main entry points after installation
- Japanese: /wasan/
- English: /wasan/en/
- JavaScript-free English reference for all 83 calculators: /wasan/en/calculators.html
- Downloads: /wasan/downloads.html and /wasan/en/downloads.html

Check after deployment
1. .mjs files are served with a JavaScript MIME type.
2. Both /wasan/ and /wasan/en/ load the calculator interface.
3. Japanese/English language links work in both directions.
4. ZIP files under downloads/ can be retrieved.
5. If the host uses a Content Security Policy, it allows the included ES modules and scripts.

See embed-snippet.html / embed-snippet-en.html for the download widget and iframe-snippet.html / iframe-snippet-en.html for iframe examples.
